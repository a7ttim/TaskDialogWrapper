﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskDialogWrapper
{
    class ClickButtonAsyncMessage : IAsyncMessage
    {
        private int buttonId = 0;

        public ClickButtonAsyncMessage(in int buttonId)
        {
            this.buttonId = buttonId;
        }

        public int Execute(IntPtr handle, TaskDialog _)
        {
            return TaskDialogAsyncMessages.ClickButtonAsync(handle, buttonId) ? 0 : 1;
        }
    }
}
