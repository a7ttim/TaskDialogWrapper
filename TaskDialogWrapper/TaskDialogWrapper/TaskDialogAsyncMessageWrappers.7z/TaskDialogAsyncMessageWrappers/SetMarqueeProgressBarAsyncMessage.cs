﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskDialogWrapper
{
    class SetMarqueeProgressBarAsyncMessage : IAsyncMessage
    {
        public int Execute(IntPtr handle, TaskDialog dialogWrapper)
        {
            return TaskDialogAsyncMessages.SetMarqueeProgressBarAsync(handle, dialogWrapper.ProgressBar.MarqueModeAsync) ? 0 : 1;
        }
    }
}
