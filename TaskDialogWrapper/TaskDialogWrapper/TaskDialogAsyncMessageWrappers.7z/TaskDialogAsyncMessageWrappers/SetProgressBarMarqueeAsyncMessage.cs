﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskDialogWrapper
{
    class SetProgressBarMarqueeAsyncMessage : IAsyncMessage
    {
        public int Execute(IntPtr handle, TaskDialog dialogWrapper)
        {
            TaskDialogAsyncMessages.SetProgressBarMarqueeAsync(handle, dialogWrapper.ProgressBar.MarqueModeAsync, dialogWrapper.ProgressBar.SpeedAsync);
            return 0;
        }
    }
}
