﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskDialogWrapper
{
    class SetProgressBarRangeAsyncMessage : IAsyncMessage
    {
        public int Execute(IntPtr handle, TaskDialog dialogWrapper)
        {
            return TaskDialogAsyncMessages.SetProgressBarRangeAsync(handle, dialogWrapper.ProgressBar.MinRangeAsync, dialogWrapper.ProgressBar.MaxRangeAsync) ? 0 : 1;
        }
    }
}
