﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskDialogWrapper
{
    class SetProgressBarStateAsyncMessage : IAsyncMessage
    {
        public int Execute(IntPtr handle, TaskDialog dialogWrapper)
        {
            return TaskDialogAsyncMessages.SetProgressBarStateAsync(handle, dialogWrapper.ProgressBar.StateAsync) ? 0 : 1;
        }
    }
}
